require 'test_helper'

class SubmissionsHelperTest < ActionView::TestCase
end
