require 'test_helper'

class MembershipsHelperTest < ActionView::TestCase
end
