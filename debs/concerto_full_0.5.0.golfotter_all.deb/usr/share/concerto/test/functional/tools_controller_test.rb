require 'test_helper'

class ToolsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
