goog.provide('concerto.frontend.ContentTypeRegistry');


/**
 * Registry for all loaded content types.
 * @type {Object}
 */
concerto.frontend.ContentTypeRegistry = {};
