module Concerto
  module VERSION
    MAJOR = 0
    MINOR = 5
    TINY = 0
    PRE = 'golfotter'

    STRING = [MAJOR, MINOR, TINY, PRE].compact.join('.')
  end
end
