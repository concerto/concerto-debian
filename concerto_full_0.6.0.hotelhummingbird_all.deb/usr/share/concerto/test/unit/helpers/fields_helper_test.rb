require 'test_helper'

class FieldsHelperTest < ActionView::TestCase
end
