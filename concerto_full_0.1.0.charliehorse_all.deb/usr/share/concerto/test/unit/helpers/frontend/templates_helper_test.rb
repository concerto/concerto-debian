require 'test_helper'

class Frontend::TemplatesHelperTest < ActionView::TestCase
end
