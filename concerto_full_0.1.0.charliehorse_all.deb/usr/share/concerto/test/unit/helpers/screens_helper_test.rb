require 'test_helper'

class ScreensHelperTest < ActionView::TestCase
end
