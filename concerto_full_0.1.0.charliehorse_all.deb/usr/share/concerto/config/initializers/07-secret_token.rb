# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Concerto::Application.config.secret_token = '55fed69ff18aa21f4ab5d3482e368c9733595fb4428e116f31ab45f4eab8e712ea87ac4daeec032d2a6c2301a8ca376f070927e65e2c609890c2e0a314948d3a'
