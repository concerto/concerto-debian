This directory should be moved to app/assets/javascripts/frontend, but right not sprockets doesn't let us not exclude it from being bundled in the application. This is fixed in Sprokets 2.2.0, 
which will hopefully be in use at some point before we release Concerto 2.
