require 'test_helper'

class ToolsHelperTest < ActionView::TestCase
end
