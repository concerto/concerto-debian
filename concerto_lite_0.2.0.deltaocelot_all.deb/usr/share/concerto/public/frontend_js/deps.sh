closure-library/closure/bin/calcdeps.py -i screen.js  -p closure-library/ -p . -o deps > deps.js
