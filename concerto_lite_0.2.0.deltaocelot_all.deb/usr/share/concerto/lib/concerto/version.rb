module Concerto
  module VERSION
    MAJOR = 0
    MINOR = 2
    TINY = 0
    PRE = 'deltaocelot'

    STRING = [MAJOR, MINOR, TINY, PRE].compact.join('.')
  end
end
