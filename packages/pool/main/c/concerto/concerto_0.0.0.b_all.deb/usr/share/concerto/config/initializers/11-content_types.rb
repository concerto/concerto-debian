# An array of all the possible content types.
# Plugins will want to append their classes to this list.
Concerto::Application.config.content_types = [Ticker, Graphic]
