require 'test_helper'

class Frontend::TemplatesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
