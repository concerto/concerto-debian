require 'test_helper'

class Frontend::FieldsHelperTest < ActionView::TestCase
end
