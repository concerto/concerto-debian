#A hash of the languages that have been fully translated and are ready for user use
#Also provide a human-readable language name
TRANSLATED_LANGUAGES = {'English' => 'en'} 